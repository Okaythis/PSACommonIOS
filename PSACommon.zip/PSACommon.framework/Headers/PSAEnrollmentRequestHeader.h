//
//  PSAEnrollmentRequestHeader.h
//  PSACommon
//
//  Created by Pivulski, Nikolai on 28.06.2018.
//

#import <PSACommon/PSACommon.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSAEnrollmentRequestHeader : PSABaseRequestHeader

@end

NS_ASSUME_NONNULL_END
