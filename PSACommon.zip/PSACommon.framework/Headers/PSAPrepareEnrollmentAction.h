//
//  PSAPrepareEnrollmentAction.h
//  PSACommon
//
//  Created by Pivulski, Nikolai on 26.06.2018.
//

#import <PSACommon/PSACommon.h>

NS_ASSUME_NONNULL_BEGIN

@interface PSAPrepareEnrollmentAction : PSABaseClientAction
@end

NS_ASSUME_NONNULL_END
