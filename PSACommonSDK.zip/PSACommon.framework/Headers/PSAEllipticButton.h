//
//  PSAEllipticButton.h
//  PSACommon
//
//  Created by Sadovsky, Aleksandr on 9/10/18.
//

#import <UIKit/UIKit.h>
#import "PSAFlatEllipticButton.h"

@interface PSAEllipticButton : PSAFlatEllipticButton

@end
