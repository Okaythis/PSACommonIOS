//
//  PSARoundButton.h
//  PSACommon
//
//  Created by Sadovsky, Aleksandr on 9/10/18.
//

#import <UIKit/UIKit.h>

@interface PSARoundButton : UIButton

@end
