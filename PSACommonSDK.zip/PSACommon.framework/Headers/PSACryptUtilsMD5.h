//
//  PSACryptUtilsMD5.h
//  PSACommon
//
//  Created by Sadovsky, Aleksandr on 7/24/18.
//

#import <Foundation/Foundation.h>

@interface PSACryptUtilsMD5 : NSObject
+ (nullable NSData *)encode:(nullable NSData *)data;
@end
